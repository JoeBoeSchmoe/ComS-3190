fetch('data.json') // Grabs Game Information
    .then(response => response.json())
    .then(data => {
    const imageDataC = data.websiteIcon[0];
    const gameImageC = document.getElementById('pongImageC');

    gameImageC.src = imageDataC.src;
    gameImageC.alt = imageDataC.alt;

    const themeImageDataA = data.themeImages[0];
    const themeImageDataB = data.themeImages[1];
    const themeImageDataC = data.themeImages[2];
    const themeImageDataD = data.themeImages[3];
    const themeImageDataE = data.themeImages[4];
    const themeImageDataF = data.themeImages[5];
    const themeImageDataG = data.themeImages[6];
    const themeImageDataH = data.themeImages[7];

    const defaultTheme = document.getElementById('defaultTheme');
    const blackTheme = document.getElementById('blackTheme');
    const redTheme = document.getElementById('redTheme');
    const orangeTheme = document.getElementById('orangeTheme');
    const yellowTheme = document.getElementById('yellowTheme');
    const greenTheme = document.getElementById('greenTheme');
    const purpleTheme = document.getElementById('purpleTheme');
    const blueTheme = document.getElementById('blueTheme');
    
    defaultTheme.src = themeImageDataA.src;
    defaultTheme.alt = themeImageDataA.alt;
    blackTheme.src = themeImageDataB.src;
    blackTheme.alt = themeImageDataB.alt;
    redTheme.src = themeImageDataC.src;
    redTheme.alt = themeImageDataC.alt;
    orangeTheme.src = themeImageDataD.src;
    orangeTheme.alt = themeImageDataD.alt;
    yellowTheme.src = themeImageDataE.src;
    yellowTheme.alt = themeImageDataE.alt;
    greenTheme.src = themeImageDataF.src;
    greenTheme.alt = themeImageDataF.alt;
    purpleTheme.src = themeImageDataG.src;
    purpleTheme.alt = themeImageDataG.alt;
    blueTheme.src = themeImageDataH.src;
    blueTheme.alt = themeImageDataH.alt;

})
.catch(error => console.error('Error fetching the JSON:', error));

const homeButton = document.getElementById("home-Button");
const settingButton = document.getElementById("settings-Button");
const contactButton = document.getElementById("contact-Button");
const accountButton = document.getElementById("account-Button");
const defaultThemeButton = document.getElementById("defaultThemeButton");
const blackThemeButton = document.getElementById("blackThemeButton");
const redThemeButton = document.getElementById("redThemeButton");
const orangeThemeButton = document.getElementById("orangeThemeButton");
const yellowThemeButton = document.getElementById("yellowThemeButton");
const greenThemeButton = document.getElementById("greenThemeButton");
const purpleThemeButton = document.getElementById("purpleThemeButton");
const blueThemeButton = document.getElementById("blueThemeButton");

const newHeader = document.getElementById('myHeader');
const newContainer = document.getElementById('myContainer');
const newLeftSideBar = document.getElementById('myLeftSideBar');
const newRightSideBar = document.getElementById('myRightSideBar');
const newFooter = document.getElementById('myFooter');

homeButton.addEventListener("click", function() {
    window.location = "./index.html";
});
settingButton.addEventListener("click", function() {
    window.location = "./settings.html";
});
contactButton.addEventListener("click", function() {
    window.location = "./contact.html";
});
accountButton.addEventListener("click", function() {
    window.location = "./account.html";
});



defaultThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'rgb(230, 230, 230)';
    newContainer.style.backgroundColor = 'rgb(230, 230, 230)';
    newLeftSideBar.style.backgroundColor = 'rgb(230, 230, 230)';
    newRightSideBar.style.backgroundColor = 'rgb(230, 230, 230)';
    newFooter.style.backgroundColor = 'rgb(230, 230, 230)';
    newFooter.style.color = 'black';

    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'black';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    
    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});

blackThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'black';
    newContainer.style.background = 'black';
    newLeftSideBar.style.backgroundColor = 'black';
    newRightSideBar.style.backgroundColor = 'black';
    newFooter.style.backgroundColor = 'black';
    newFooter.style.color = 'white';

    document.body.style.color = 'white';
    homeButton.style.backgroundColor = 'darkgray';
    settingButton.style.backgroundColor = 'rgb(50, 50, 50)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'darkgray';
    accountButton.style.backgroundColor = 'darkgray';

    homeButton.style.borderColor = 'rgb(25,25,25)';
    settingButton.style.borderColor = 'rgb(25,25,25)';
    contactButton.style.borderColor = 'rgb(25,25,25)';
    accountButton.style.borderColor = 'rgb(25,25,25)';
});

redThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'red';
    newContainer.style.background = 'red';
    newLeftSideBar.style.backgroundColor = 'red';
    newRightSideBar.style.backgroundColor = 'red';
    newFooter.style.backgroundColor = 'red';
    newFooter.style.color = 'white';

    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'rgb(150, 5, 5)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});

orangeThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'orange';
    newContainer.style.background = 'orange';
    newLeftSideBar.style.backgroundColor = 'orange';
    newRightSideBar.style.backgroundColor = 'orange';
    newFooter.style.backgroundColor = 'orange';
    newFooter.style.color = 'black';

    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'rgb(250, 100, 5)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});

yellowThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'yellow';
    newContainer.style.background = 'yellow';
    newLeftSideBar.style.backgroundColor = 'yellow';
    newRightSideBar.style.backgroundColor = 'yellow';
    newFooter.style.backgroundColor = 'yellow';
    newFooter.style.color = 'black';

    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'rgb(170, 160, 25)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});

greenThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'green';
    newContainer.style.background = 'green';
    newLeftSideBar.style.backgroundColor = 'green';
    newRightSideBar.style.backgroundColor = 'green';
    newFooter.style.backgroundColor = 'green';
    newFooter.style.color = 'white';


    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'rgb(0, 80, 30)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});

purpleThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'purple';
    newContainer.style.background = 'purple';
    newLeftSideBar.style.backgroundColor = 'purple';
    newRightSideBar.style.backgroundColor = 'purple';
    newFooter.style.backgroundColor = 'purple';
    newFooter.style.color = 'white';


    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'rgb(50, 0, 80)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});

blueThemeButton.addEventListener("click", function() {
    newHeader.style.backgroundColor = 'blue';
    newContainer.style.background = 'blue';
    newLeftSideBar.style.backgroundColor = 'blue';
    newRightSideBar.style.backgroundColor = 'blue';
    newFooter.style.backgroundColor = 'blue';
    newFooter.style.color = 'white';


    document.body.style.color = 'black';
    homeButton.style.backgroundColor = 'white';
    settingButton.style.backgroundColor = 'rgb(10, 25, 100)';
    settingButton.style.color = 'white';
    contactButton.style.backgroundColor = 'white';
    accountButton.style.backgroundColor = 'white';

    homeButton.style.borderColor = 'black';
    settingButton.style.borderColor = 'black';
    contactButton.style.borderColor = 'black';
    accountButton.style.borderColor = 'black';
});
