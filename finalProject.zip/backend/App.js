/**
 * 
 * Author: Joseph Sheets
 * ISU NetID: JSheets1@IAState.edu
 * Date: December 4, 2024
 * 
 */

const express = require("express");
const cors = require("cors");
const { MongoClient } = require("mongodb");
const bodyParser = require("body-parser");
const fs = require("fs");
const multer = require("multer");
const path = require("path");

const port = "8081";
const host = "localhost";
const url = "mongodb://127.0.0.1:27017";
const dbName = "FinalProject";
const client = new MongoClient(url);

var app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.json());
app.use(express.static("public"));
app.use("/uploads", express.static("uploads")); // Serve images statically


let db;
// Connect to MongoDB once and reuse the connection
async function connectToDatabase() {
    if (!db) {
        try {
            await client.connect();
            db = client.db(dbName);
            console.log("Connected to MongoDB database:", dbName);
        } 
        catch (error) {
            console.error("Failed to connect to MongoDB:", error);
            process.exit(1); // Exit the app if the database connection fails
        }
    }
}

function getTodayDate() {
    const today = new Date(); // Get the current date
    const day = String(today.getDate()).padStart(2, "0"); // Get the day and pad with 0 if needed
    const month = String(today.getMonth() + 1).padStart(2, "0"); // Months are 0-based, so add 1
    const year = today.getFullYear(); // Get the 4-digit year
    return `${month}/${day}/${year}`; // Return in MM/DD/YYYY format
}

// Middleware to ensure the database connection
app.use(async (req, res, next) => {
    if (!db) {
        await connectToDatabase();
    }
    next();
});

// Start the server
app.listen(port, () => {
    console.log(`App listening at http://${host}:${port}`);
});

// Default route
app.get("/", (req, res) => {
    res.status(200).send("Hello From Server");
    console.log("Hello From Server");
});

app.get("/listImages", async (req, res) => {
    try {
        const images = await db.collection("generalImages").find({}).toArray();
        if (!images || images.length === 0) {
            return res.status(404).send({ error: "No images found." });
        }
        //console.log("Images retrieved:", images);
        res.status(200).send(images);
    } catch (error) {
        console.error("Error retrieving images:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});


app.get("/image/:id", async (req, res) => {
    try {
        const id = req.params.id; // Get ID from the route parameter
        const account = await db.collection("generalImages").findOne({ imageID: Number(id) });

        if (!account) {
            return res.status(404).send({ error: "Image not found." });
        }

        console.log("Image retrieved:", account);
        res.status(200).send(account);
    } 
    catch (error) {
        console.error("Error retrieving image by ID:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});

app.get("/contactPage", async (req, res) => {
    try {
        const accounts = await db.collection("contactPage").find({}).limit(100).toArray();
        //console.log("contact images retrieved:", accounts);
        res.status(200).send(accounts);
    } 
    catch (error) {
        console.error("Error retrieving contact images:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});

app.delete("/deleteAccount/:id", async (req, res) => {
    try {
        const id = Number(req.params.id); // Get ID from the route parameter
        const result = await db.collection("accounts").deleteOne({ accountID: id });
        if (result.deletedCount === 0) {
            return res.status(404).send({ error: "Account not found." });
        }

        console.log("Account deleted with ID:", id);
        res.status(200).send({ message: "Account deleted successfully." });
    } catch (error) {
        console.error("Error deleting account:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});

app.post("/addAccount", async (req, res) => {
    try {

        if (!req.body || Object.keys(req.body).length === 0) {
            return res.status(400).send({ error: "Bad request: No data provided." });
        }

        const { username, password, admin, dateCreated, accountPFPURL, colorPreset, pongHighScore} = req.body;

        // Fetch all existing accounts and find the next available accountID
        const accounts = await db.collection("accounts").find({}).toArray();
        const takenIds = accounts.map(account => account.accountID);
        let newAccountID = 1;

        while (takenIds.includes(newAccountID)) {
            newAccountID++;
        }

        const newAccount = {
            username,
            password,
            admin, 
            dateCreated, // Add creation date
            accountPFPURL: "https://robohash.org/robot" + accountPFPURL,
            colorPreset,
            pongHighScore,
            accountID: newAccountID // Assign the next available ID
        };

        // Insert the new account into the database
        await db.collection("accounts").insertOne(newAccount);
        console.log("Account added:", newAccount);
        res.status(201).send({ message: "Account added successfully.", account: newAccount });
    } catch (error) {
        console.error("Error adding account:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});


app.put("/updateAccount/:id", async (req, res) => {
    try {
        const id = Number(req.params.id); // Get ID from the route parameter
        const updates = req.body;

        // Validate that there's something to update
        if (!updates || Object.keys(updates).length === 0) {
            return res.status(400).send({ error: "No updates provided." });
        }

        const result = await db.collection("accounts").updateOne(
            { accountID: id },
            { $set: updates }
        );

        if (result.matchedCount === 0) {
            return res.status(404).send({ error: "Account not found." });
        }

        console.log("Account updated with ID:", id, "Updates:", updates);
        res.status(200).send({ message: "Account updated successfully.", updates });
    } catch (error) {
        console.error("Error updating account:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});

app.get("/listAccounts", async (req, res) => {
    try {
        const accounts = await db.collection("accounts").find({}).limit(100).toArray();
        //console.log("Accounts retrieved:", accounts);
        res.status(200).send(accounts);
    } catch (error) {
        console.error("Error retrieving accounts:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});

app.get("/account/:id", async (req, res) => {
    try {
        const id = Number(req.params.id); // Get ID from the route parameter
        const account = await db.collection("accounts").findOne({ accountID: id });

        if (!account) {
            return res.status(404).send({ error: "Account not found." });
        }

        console.log("Account retrieved:", account);
        res.status(200).send(account);
    } catch (error) {
        console.error("Error retrieving account by ID:", error);
        res.status(500).send({ error: "An internal server error occurred." });
    }
});
