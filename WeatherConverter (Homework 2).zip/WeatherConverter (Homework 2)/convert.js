/**
 * Author: Joseph Sheets
 * Last Edited: 09/29/24
 */
window.addEventListener("DOMContentLoaded", domLoaded);
//console.log(cInput);

function domLoaded() {
   const convertButton = document.getElementById('convertButton');
   const celsiusInput = document.getElementById('cInput');
   const fahrenheitInput = document.getElementById('fInput');
   const myErrorMsg = document.getElementById('errorMessage');
   const tempWeather = document.getElementById('weatherImage');

   if(convertButton){
      celsiusInput.addEventListener('input', function() {
         fahrenheitInput.value = '';
      });
      fahrenheitInput.addEventListener('input', function () {
         celsiusInput.value = '';
      });
      convertButton.addEventListener('click', function() {
         myErrorMsg.innerText = '';
         const celsiusValue = parseFloat(celsiusInput.value);
         const fahrenheitValue = parseFloat(fahrenheitInput.value);
         if (celsiusInput.value != '') {
            if (isNaN(celsiusValue)) {
               console.log(celsiusInput.value + " is not a number");
               myErrorMsg.innerText = (celsiusInput.value + " is not a number");
               celsiusInput.value = '';

            }
            else {
               const convertedCF = convertCtoF(celsiusValue);
               fahrenheitInput.value = convertedCF;
               if(fahrenheitInput.value > 50) {
                  tempWeather.src = "images/warm.png";
               }
               else if(fahrenheitInput.value >= 32 && fahrenheitInput.value <= 50) {
                  tempWeather.src = "images/cool.png";
               }
               else if(fahrenheitInput.value < 32) {
                  tempWeather.src = "images/cold.png"
               }
               celsiusInput.value = '';
            }
         }
         else if(fahrenheitInput.value != '') {
            if (isNaN(fahrenheitValue)) {
               console.log(fahrenheitInput.value + " is not a number");
               myErrorMsg.innerText = (fahrenheitInput.value + " is not a number");
               fahrenheitInput.value = '';
            }
            else {
               const convertedFC = convertFtoC(fahrenheitValue);
               celsiusInput.value = convertedFC;
               if (celsiusInput.value > 10) {
                  tempWeather.src = "images/warm.png";
               }
               else if (celsiusInput.value >= 0 && celsiusInput.value <= 10) {
                  tempWeather.src = "images/cool.png";
               }
               else if (celsiusInput.value < 0) {
                  tempWeather.src = "images/cold.png"
               }
               fahrenheitInput.value = '';
            }
         }           
      });
   }
   else {
      console.log("NOT FOUND");
   }
}

function convertCtoF(degreesCelsius) {
   return (degreesCelsius * (9 / 5) + 32);
}

function convertFtoC(degreesFahrenheit) {
   return ((degreesFahrenheit - 32) * (5/9))
}
